document.addEventListener("DOMContentLoaded", function() {
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');
    const fileList = document.getElementById('fileList');
    const MAX_IMAGES = 5;

    

    dropzone.addEventListener('dragover', function(e) {
        e.preventDefault();
        dropzone.classList.add('dragover');
    });

    dropzone.addEventListener('dragleave', function(e) {
        e.preventDefault();
        dropzone.classList.remove('dragover');
    });

    dropzone.addEventListener('drop', function(e) {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        handleFiles(e.dataTransfer.files);
    });

    fileInput.addEventListener('change', function() {
        handleFiles(fileInput.files);
    });

    function handleFiles(files) {
        if (fileList.children.length + files.length > MAX_IMAGES) {
            alert('You can only upload a maximum of 5 images.');
            return;
        }

        Array.from(files).forEach(file => {
            if (file.size > 1024 * 1024) {
                alert(`${file.name} is too large. Maximum file size is 1 MB.`);
                return;
            }
            if (!file.type.startsWith('image/')) {
                alert(`${file.name} is not a valid image.`);
                return;
            }
            displayFile(file);
        });
    }

    function displayFile(file) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            const div = document.createElement('div');
            div.className = 'file-name';
            
            const img = document.createElement('img');
            img.src = e.target.result;
            img.alt = file.name;
            img.className = 'thumbnail';
            div.appendChild(img);

            const textarea = document.createElement('textarea');
            textarea.placeholder = 'Add description';
            div.appendChild(textarea);

            const deleteBtn = document.createElement('span');
            deleteBtn.textContent = '❌';
            deleteBtn.className = 'delete-btn';
            deleteBtn.addEventListener('click', () => {
                div.remove();
                saveToLocalStorage();
                updateBackgroundImage(); // Update background image after deletion
            });
            div.appendChild(deleteBtn);

            fileList.appendChild(div);
            saveToLocalStorage();
            updateBackgroundImage(); // Update background image after adding a file
        }

        reader.readAsDataURL(file);
    }

    function saveToLocalStorage() {
        const files = Array.from(fileList.children).map(fileDiv => {
            const img = fileDiv.querySelector('img');
            const textarea = fileDiv.querySelector('textarea');
            return {
                src: img.src,
                description: textarea.value
            };
        });
        localStorage.setItem('storedImagesData', JSON.stringify(files));
    }

    function loadFromLocalStorage() {
        const storedImagesData = JSON.parse(localStorage.getItem('storedImagesData') || '[]');
        storedImagesData.forEach(data => {
            const div = document.createElement('div');
            div.className = 'file-name';

            const img = document.createElement('img');
            img.src = data.src;
            img.className = 'thumbnail';
            div.appendChild(img);
            
            const textarea = document.createElement('textarea');
            textarea.value = data.description;
            div.appendChild(textarea);

            const deleteBtn = document.createElement('span');
            deleteBtn.textContent = '❌';
            deleteBtn.className = 'delete-btn';
            deleteBtn.addEventListener('click', () => {
                div.remove();
                saveToLocalStorage();
                updateBackgroundImage(); // Update background image after deletion
            });
            div.appendChild(deleteBtn);

            fileList.appendChild(div);
        });
        updateBackgroundImage(); // Update background image on load
    }

    loadFromLocalStorage();
});

