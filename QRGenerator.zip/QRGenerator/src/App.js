import React from 'react';
import './App.css';
import QrCodeCard from './components/QrCodeCard';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>QR Code Generator</h1>
        <QrCodeCard />
      </header>
    </div>
  );
}

export default App;
