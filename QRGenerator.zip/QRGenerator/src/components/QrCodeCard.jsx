import React, { useState } from 'react';
import QRCode from 'qrcode';

function QrCodeCard() {
  const [url, setUrl] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const generateQRCode = async () => {
    setError('');
    if (!url) {
      setError('Enter The Url');
      setTimeout(() => setError(''), 5000);
      return;
    }

    setLoading(true);

    try {
      const dataUrl = await QRCode.toDataURL(url);
      setQrCodeUrl(dataUrl);
    } catch (err) {
      setQrCodeUrl('');
      setError('Invalid URL');
      setTimeout(() => setError(''), 5000);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      generateQRCode();
    }
  };

  const clearQRCode = () => {
    setUrl('');
    setQrCodeUrl('');
    setError('');
  };

  return (
    <div className="qr-code-card">
      <input
        type="url"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        placeholder="Enter URL"
        className="input-field"
        onKeyPress={handleKeyPress}
      />
      <button id="generate-btn" onClick={generateQRCode} className="button">
        {loading ? 'Generating...' : 'Generate'}
      </button>
      <button id="clear-btn" onClick={clearQRCode} className="button">
        Clear
      </button>
      {qrCodeUrl && (
        <div className="qr-code-container">
          <img src={qrCodeUrl} alt="qr-code" />
          <a download="qrCode.png" href={qrCodeUrl} className="button">
            Download
          </a>
        </div>
      )}
      {error && <div className="alert mt-2 mb-1">{error}</div>}
    </div>
  );
}

export default QrCodeCard;
