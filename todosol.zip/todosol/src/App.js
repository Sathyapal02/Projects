import './App.css';
import ContentBox from './HOC/contentBox/ContentBox';
import Header from './components/Header';
import TodoBox from './components/todoBox/TodoBox';

function App() {
  return (
    <div className="App">
      <nav className="navbar">
        <span style={{fontSize: '2rem', fontWeight: '600', letterSpacing: '0.4rem' }}>TodoApp</span>
      </nav>
      <ContentBox>
        <Header />
      </ContentBox>
      <ContentBox>
        <TodoBox />
      </ContentBox>
    </div>
  );
}

export default App;
