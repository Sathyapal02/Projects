import React from 'react'
import './contentBox.css'

function ContentBox({children}) {
  return (
    <div className='content-box'>
        {children}
    </div>
  )
}

export default ContentBox