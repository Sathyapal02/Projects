import React from 'react'
import './taskCard.css'

function TaskCard({id, title,description, setTodoItems, setUpdateData}) {

    function handleDeleteThisTask(){
        const LS_Data = JSON.parse(localStorage.getItem('todoData'));
        const otherArrayData = LS_Data.filter(item => item.id !== id);

        localStorage.setItem('todoData', JSON.stringify(otherArrayData));

        setTodoItems(otherArrayData)

        const modal = document.querySelectorAll('.modal-container')[1];
        modal.classList.remove('isOpen')
    }

    function handleEditTask() {
        const updateModal = document.querySelectorAll('.modal-container')[1];
        updateModal.classList.toggle('isOpen');

        setUpdateData({
            id: id,
            title: title,
            description: description,
        })
        // yahan se start krna hai 
        // update the current detail of model into the localstorage 
    }

  return (
    <div className='taskCard-container'>
        <h4>{title}</h4>
        <p style={{fontSize: '0.8rem', height: '100px', overflow: 'hidden', textOverflow:'ellipsis' }}>{description}</p>
        <div className="group-icons">
            <i className='far fa-edit m-3' onClick={handleEditTask}> </i>
            <i className='fas fa-trash-alt' onClick={handleDeleteThisTask}> </i>
        </div>
    </div>
  )
}

export default TaskCard