import React from 'react'
import './button.css'

function Button({classname, children, onClick}) {
  return (
    <div className={`btn ${classname}`} onClick={onClick}>
      {children}
    </div>
  )
}

export default Button