const audio = document.getElementById('audio');
const playBtn = document.querySelector('.play');
const skipForwardBtn = document.querySelector('.skip-forward');
const skipBackBtn = document.querySelector('.skip-back');
const progressBar = document.querySelector('.progress-bar');
const progressHead = document.querySelector('.progress-head');
const currentTimeElem = document.querySelector('.current-time');
const audioTitle = document.querySelector('.audio-title');
const audioSinger = document.querySelector('.audio-singer');
const audioImg = document.querySelector('.audio-img img');

let currentTrackIndex = 0;
const tracks = [
    {
        name: "Let me down slowly",
        artist: "Alec Benjamin",
        cover: "alec.jpeg",
        source: "Let me down slowly.mp3",
    },
    {
        name: "Let me love you",
        artist: "DJ Snake/Justin Beiber",
        cover: "dj.jpeg",
        source: "Let me love you.mp3",
    },
    {
        name: "Perfect",
        artist: "Ed Sheeran",
        cover: "ed.jpg",
        source: "Perfect.mp3",
    },
];

function loadTrack(index) {
    const track = tracks[index];
    audio.src = track.source;
    audioTitle.textContent = track.name;
    audioSinger.textContent = track.artist;
    audioImg.src = track.cover;

    // Reset progress bar
    progressBar.style.width = `0%`;
    progressHead.style.left = `0%`;

    // Reset time display
    currentTimeElem.textContent = `00:00/00:00`;

    // Load metadata to get duration
    audio.addEventListener('loadedmetadata', () => {
        const duration = audio.duration;
        const minutes = Math.floor(duration / 60);
        const seconds = Math.floor(duration % 60).toString().padStart(2, '0');
        const durationText = `${minutes}:${seconds}`;
        currentTimeElem.textContent = `00:00/${durationText}`;
    });
}

function playTrack() {
    audio.play();
    playBtn.querySelector('i').classList.remove('fa-play');
    playBtn.querySelector('i').classList.add('fa-pause');
}

function pauseTrack() {
    audio.pause();
    playBtn.querySelector('i').classList.add('fa-play');
    playBtn.querySelector('i').classList.remove('fa-pause');
}

function updateProgress() {
    const { duration, currentTime } = audio;
    const progressPercent = (currentTime / duration) * 100;
    progressBar.style.width = `${progressPercent}%`;
    progressHead.style.left = `${progressPercent}%`;

    const minutesCurrent = Math.floor(currentTime / 60);
    const secondsCurrent = Math.floor(currentTime % 60).toString().padStart(2, '0');
    const durationText = currentTimeElem.textContent.split('/')[1]; // Get the total duration part
    currentTimeElem.textContent = `${minutesCurrent}:${secondsCurrent}/${durationText}`;
}

function setProgress(e) {
    const width = this.clientWidth;
    const clickX = e.offsetX;
    const duration = audio.duration;

    audio.currentTime = (clickX / width) * duration;
}

playBtn.addEventListener('click', () => {
    if (audio.paused) {
        playTrack();
    } else {
        pauseTrack();
    }
});

skipForwardBtn.addEventListener('click', () => {
    currentTrackIndex = (currentTrackIndex + 1) % tracks.length;
    loadTrack(currentTrackIndex);
    playTrack();
});

skipBackBtn.addEventListener('click', () => {
    currentTrackIndex = (currentTrackIndex - 1 + tracks.length) % tracks.length;
    loadTrack(currentTrackIndex);
    playTrack();
});

audio.addEventListener('timeupdate', updateProgress);
audio.addEventListener('ended', () => {
    currentTrackIndex = (currentTrackIndex + 1) % tracks.length;
    loadTrack(currentTrackIndex);
    playTrack();
});

document.querySelector('.progress').addEventListener('click', setProgress);

loadTrack(currentTrackIndex);
