import React, {useState} from 'react'
import './todoBox.css'
import Button from '../button/Button'
import CreateTask from '../../modals/CreateTask'
import EditTask from '../../modals/EditTask'
import TaskCard from './taskCard/TaskCard'

function TodoBox() {
    const [todoItems, setTodoItems] = useState(JSON.parse(localStorage.getItem('todoData')))
    const [updateData, setUpdateData] = useState({
        id:'',
        title: '',
        description: '',
    })


    const handleDisplayCreateModal = () => {
        const modal = document.querySelector('.modal-container')
        modal.classList.add('isOpen')
    }

  return (
    <div className='todo-container'>
        <CreateTask modalType='create' setTodoItems={setTodoItems}/>
        <EditTask modalType='update' data={updateData} setTodoItems={setTodoItems}/>
        <div className="header">
            <h1>Click below Button to create new TODO tasks. 👇</h1>
            <Button classname='create-task' onClick={handleDisplayCreateModal}>Create Todo </Button>
        </div>
        <div className="task-container">
            {todoItems && todoItems.map(item => <TaskCard key={item.id} id={item.id} title={item.title} description={item.description} setTodoItems={setTodoItems} setUpdateData={setUpdateData} />)}
        </div>
    </div>
  )
}

export default TodoBox