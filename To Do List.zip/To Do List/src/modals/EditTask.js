import React, {useState, useEffect} from 'react'
import Button from '../components/button/Button';

function EditTask({modalType, data, setTodoItems}) {

    useEffect(() => {
      setTask({
        id: data?.id,
        title: data?.title,
        description: data?.description,
    })
    }, [data])
    
    const [task, setTask] = useState({
        id: data?.id,
        title: data?.title,
        description: data?.description,
    })

    const {id, title, description} = task;

    function handleCancelTodo(){

        const modal = document.querySelectorAll('.modal-container')[1];
        modal.classList.remove('isOpen')
    }

    function handleOnChangeInput(e){
        setTask({
            ...task,
            [e.target.id]: e.target.value,
        })
    }

    function handlUpdateDataInLS(){
        const LS_Data = JSON.parse(localStorage.getItem('todoData'));
        const otherArrayData = LS_Data.filter(item => item.id !== id);

        otherArrayData.push(task)
        localStorage.setItem('todoData', JSON.stringify(otherArrayData));

        setTodoItems(otherArrayData)

        const modal = document.querySelectorAll('.modal-container')[1];
        modal.classList.remove('isOpen')
    }
    


  return (
    <div className='modal-container'>
        <div className="input-box">
            <label htmlFor="title">Title</label>
            <input name='updateTaskName' type="text" id='title' className='inputTitle' value={title} onChange={handleOnChangeInput}/>
        </div>

        <div className="input-box">
            <label htmlFor="description">Description</label>
            <textarea name='updateTaskDescription' type="text" id='description' className='inputDesc' rows={10} cols={40} value={description} onChange={handleOnChangeInput}/>
        </div>

        <div className="button-container">
            <Button classname={modalType} onClick={handlUpdateDataInLS}>
                {modalType}
            </Button>
            <Button classname='cancel' onClick={handleCancelTodo}>
                Cancel
            </Button>
        </div>
    </div>
  )
}

export default EditTask