import React, {useState} from 'react'
import './modalStyles.css'
import Button from '../components/button/Button'


function CreateTask({modalType, setTodoItems}) {
    const [newTask, setNewTask] = useState({
        title: '',
        description: '',
    })

    const {title, description} = newTask;

    function handleCancelTodo(){
        const modal = document.querySelector('.modal-container');
        modal.classList.remove('isOpen')
    }

    function handleOnChangeInput(e){
        setNewTask({
            ...newTask,
            [e.target.id]: e.target.value,
        })
    }

    function handleToCreateNewTodo() {
        // checks :- title and description should be filled
        if(title === '' || description === ''){
            const errorMsgElement = document.querySelector('.msg');
            errorMsgElement.classList.toggle('error-msg')
            errorMsgElement.textContent = 'All Fields are required';

            setTimeout(() => {
                errorMsgElement.classList.toggle('error-msg')
                errorMsgElement.textContent = 'Write your New ToDo';
            }, 2000);
            return;
        }

        let lcData = JSON.parse(localStorage.getItem('todoData'));

        // ........This is alternative way of doing below ........
        // if(lcData){ // current data is not the first data, some are already present
        //     lcData.push(newTask);
        //     localStorage.setItem('todoData', JSON.stringify(lcData));
        // }else{  // this is the first data to be stored in local storage
        //     const array = new Array();
        //     array.push(newTask);
        //     localStorage.setItem('todoData', JSON.stringify(array));
        // }

        if(lcData === null){
            lcData = new Array();
            localStorage.setItem('uniqueID', 0);
        }

        const uniqueID = Number(localStorage.getItem('uniqueID')) + 1;
        lcData.push({...newTask, id: uniqueID})
        localStorage.setItem('uniqueID', uniqueID);
        localStorage.setItem('todoData', JSON.stringify(lcData));

        handleCancelTodo();
        setNewTask({
            title: '',
            description: '',
        })
        setTodoItems(lcData);
    }

  return (
    <div className='modal-container'>
        <p className="msg">Write your New ToDo</p>
        <div className="input-box">
            <label htmlFor="title">Title</label>
            <input name='createTaskName' type="text" id='title' className='inputTitle' value={title} onChange={handleOnChangeInput}/>
        </div>

        <div className="input-box">
            <label htmlFor="description">Description</label>
            <textarea name="createTaskDescription" type="text" id='description' className='inputDesc' rows={10} cols={40} value={description} onChange={handleOnChangeInput}/>
        </div>

        <div className="button-container">
            <Button classname={modalType} onClick={handleToCreateNewTodo}>
                {modalType}
            </Button>
            <Button classname='cancel' onClick={handleCancelTodo}>
                Cancel
            </Button>
        </div>
    </div>
  )
}

export default CreateTask