document.getElementById('location-form').addEventListener('submit', getWeather);

async function getWeather(e) {
  e.preventDefault();

  const location = document.getElementById('location-input').value;
  const apiKey = '5797843e83ab412f3146ffbe0be37357'; // Your actual API key
  const apiUrl = `http://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}&units=metric`;
  const weatherDataDiv = document.getElementById('weather-data');
  
  weatherDataDiv.innerHTML = ''; // Clear previous data

  try {
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error('Error: City not found');
    }
    const data = await response.json();
    displayWeather(data);
  } catch (error) {
    weatherDataDiv.innerHTML = `<div id="error">${error.message}</div>`;
  }
}

function displayWeather(data) {
  const weatherDataDiv = document.getElementById('weather-data');
  const { name, main, weather } = data;

  const weatherHTML = `
    <h2>Weather in ${name}</h2>
    <p>Temperature: ${main.temp}°C</p>
    <p>Weather: ${weather[0].description}</p>
    <p>Humidity: ${main.humidity}%</p>
  `;

  weatherDataDiv.innerHTML = weatherHTML;
}
